import * as api from "./api.js"; 

console.log("creating player...");
const accounts = await api.createPlayer();
